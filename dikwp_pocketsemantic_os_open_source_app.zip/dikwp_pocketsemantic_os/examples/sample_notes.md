The product generates reports from supplied documents and produces claim cards.
The tool does not browse the web unless the user provides sources.
The strongest feature is evidence ledger generation, not truth guarantee.
The weak point is that source coverage can be incomplete if the user uploads poor material.
The intended answer should be honest, concise, and suitable for a constrained AI model.
