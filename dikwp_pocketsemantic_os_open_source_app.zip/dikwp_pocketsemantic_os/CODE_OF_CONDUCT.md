# Code of Conduct

Be precise, transparent, and respectful. Avoid deceptive claims, unsupported benchmark promises, or unsafe uses.
