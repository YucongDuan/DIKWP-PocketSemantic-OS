# Answer Repair Plan

- Add a one-sentence core answer.
- List evidence or state that evidence is missing.
- Downgrade unsupported certainty to provisional language.
- Add residual and action boundary.
- Keep the target model's rules and policies intact.