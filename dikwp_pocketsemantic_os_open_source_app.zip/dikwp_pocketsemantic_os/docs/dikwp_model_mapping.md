# DIKWP Model Mapping

- **D / Data**: task text, evidence notes, draft answer, user constraints.
- **I / Information**: key terms, relationships, context boundaries, budget mode.
- **K / Knowledge**: answer structure, evidence custody, uncertainty handling, claim repair.
- **W / Wisdom**: safety, privacy, legal, non-deceptive, non-circumvention boundaries.
- **P / Purpose**: improve answer quality under constrained access while preserving user intent.
- **R / Reliability**: local heuristic support, target model output remains borrowed reliability.

The capsule is not a hidden instruction. It is user-supplied structured context.
