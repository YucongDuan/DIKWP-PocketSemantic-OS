# Architecture

DIKWP PocketSemantic OS has five layers:

1. **Input Layer**: accepts task text, evidence notes, and budget profile.
2. **Boundary Guard**: detects requests that appear to ask for access circumvention, prompt injection, hidden-prompt extraction, unsafe stealth, or data exfiltration.
3. **DIKWP Compiler**: registers the task as Data, Information, Knowledge, Wisdom, Purpose, and Reliability.
4. **Capsule Renderer**: renders a model-agnostic prompt capsule in micro, low, normal, or audit mode.
5. **Answer Enhancer**: reviews a draft answer for unsupported certainty, missing evidence, missing residual, and missing action boundary.

The system is offline-first. It does not call external APIs, perform network requests, mutate the host system, or create background persistence.
