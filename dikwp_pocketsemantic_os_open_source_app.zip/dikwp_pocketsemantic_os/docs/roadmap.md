# Roadmap

## v0.2
- More capsule templates.
- Multilingual prompts.
- Better unsupported claim scoring.
- Browser copy helper.

## v0.3
- MCP-style local context server without dangerous tool execution.
- OpenTelemetry-style capsule usage logs.
- Integration with ProofLedger and AgentTrace.

## v0.4
- Team semantic capsule library.
- Local vectorless retrieval from user-supplied notes.
- Enterprise policy packs.

## v1.0
- Full DIKWP TrustOS portable semantic layer.
