# GitHub Release Draft

## v0.1.0 - Portable DIKWP Semantic Capsules

Initial release of DIKWP PocketSemantic OS.

Features:

- DIKWP semantic capsule builder.
- Micro/low/normal/audit budget modes.
- Answer enhancement and repair plan.
- Boundary guard against bypass/jailbreak framing.
- Offline-first CLI.
- Static boundary audit.

This release is intended for lawful semantic augmentation and answer quality improvement under constrained AI access.
