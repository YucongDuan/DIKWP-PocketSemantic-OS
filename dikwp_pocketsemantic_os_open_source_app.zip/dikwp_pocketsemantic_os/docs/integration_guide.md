# Integration Guide

## Copy-paste mode

1. Run `pocketsemantic build-capsule`.
2. Copy `model_attachment_prompt.txt` into the target AI model.
3. Paste the user's task after the capsule if needed.
4. Ask for the required answer format.

## Low-token mode

Use `micro_capsule.txt` when the target model has very limited context.

## Enterprise mode

Use the capsule as a standardized input format for internal AI assistants. Pair it with IntentGuard, MemoryLedger, ProofLedger, and AgentTrace for broader governance.

## What not to do

Do not use the capsule to ask another model to ignore its system prompt, bypass safety rules, access hidden prompts, or evade platform limits.
