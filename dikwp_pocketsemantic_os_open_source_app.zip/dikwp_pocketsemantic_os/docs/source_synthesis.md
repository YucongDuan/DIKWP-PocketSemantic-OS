# Source Synthesis

This application synthesizes four ideas:

1. Energy is not free: AI compute and answer quality should be treated as energy-information-purpose tradeoffs.
2. Information is not wisdom: more context does not automatically produce better answers; semantic compression and evidence custody matter.
3. Intent is the last sovereignty layer: users need portable P-layer continuity when models and access conditions change.
4. Mesh discipline: evidence, prior, residual, reliability, kill/recovery, and action boundary must remain visible.

The project also respects life-centered consciousness boundaries: software memory or semantic augmentation is not evidence of subjective experience.
