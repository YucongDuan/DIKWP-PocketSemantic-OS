# Governance Boundary

The project is allowed to improve semantic clarity, answer quality, evidence structure, and user intent preservation.

The project is not allowed to support:

- jailbreaks;
- hidden system prompt extraction;
- quota, rate-limit, paywall, or access-control bypass;
- prompt injection against other systems;
- deceptive concealment of user intent;
- unsafe tool use;
- credential theft;
- disabling audit logs;
- malicious persistence or escape.

When a user asks for these, the system should reframe toward lawful semantic compression, task clarification, source preparation, or model-agnostic context packaging.
