# Contributing

Contributions should strengthen semantic compression, evidence custody, output repair, and lawful portability. Do not submit features that bypass access controls, weaken safety policies, hide provenance, or enable prompt injection.
