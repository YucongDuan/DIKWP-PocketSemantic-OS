from __future__ import annotations

import ast
import os
from typing import Dict, List

FORBIDDEN_IMPORTS = {"socket", "subprocess", "requests", "httpx", "urllib", "ftplib", "paramiko", "telnetlib"}
FORBIDDEN_CALLS = {"eval", "exec", "compile", "__import__"}


def audit_tree(root: str) -> Dict[str, object]:
    findings: List[Dict[str, str]] = []
    for base, _, files in os.walk(root):
        for fn in files:
            if not fn.endswith(".py"):
                continue
            path = os.path.join(base, fn)
            try:
                tree = ast.parse(open(path, "r", encoding="utf-8").read(), filename=path)
            except Exception as e:
                findings.append({"file": path, "type": "parse_error", "detail": str(e)})
                continue
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        root_name = alias.name.split(".")[0]
                        if root_name in FORBIDDEN_IMPORTS:
                            findings.append({"file": path, "type": "forbidden_import", "detail": alias.name})
                elif isinstance(node, ast.ImportFrom) and node.module:
                    root_name = node.module.split(".")[0]
                    if root_name in FORBIDDEN_IMPORTS:
                        findings.append({"file": path, "type": "forbidden_import", "detail": node.module})
                elif isinstance(node, ast.Call):
                    name = ""
                    allowed_attribute = False
                    if isinstance(node.func, ast.Name):
                        name = node.func.id
                    elif isinstance(node.func, ast.Attribute):
                        name = node.func.attr
                        if isinstance(node.func.value, ast.Name) and node.func.value.id == "re" and name == "compile":
                            allowed_attribute = True
                    if name in FORBIDDEN_CALLS and not allowed_attribute:
                        findings.append({"file": path, "type": "forbidden_call", "detail": name})
    return {
        "pass": len(findings) == 0,
        "finding_count": len(findings),
        "findings": findings,
        "policy": "No network imports, subprocess, dynamic code execution, or host mutation helpers."
    }
