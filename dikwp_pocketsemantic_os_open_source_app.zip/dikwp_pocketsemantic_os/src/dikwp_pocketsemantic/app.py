from __future__ import annotations

try:
    import streamlit as st
except Exception:  # pragma: no cover
    st = None

from .analyzer import make_capsule, micro_capsule, model_attachment_prompt


def main() -> None:  # pragma: no cover
    if st is None:
        raise RuntimeError("Install with pip install -e .[app] to use the Streamlit UI.")
    st.title("DIKWP PocketSemantic OS")
    st.caption("Portable semantic capsule builder for constrained AI access.")
    task = st.text_area("Task", height=180)
    notes = st.text_area("Evidence or notes", height=160)
    budget = st.selectbox("Budget", ["micro", "low", "normal", "audit"], index=1)
    if st.button("Build capsule") and task:
        cap = make_capsule(task, notes, budget=budget)
        st.subheader("Model attachment prompt")
        st.text_area("Copy this into the target model", model_attachment_prompt(cap), height=360)
        st.subheader("Micro capsule")
        st.code(micro_capsule(cap))
        st.json(cap.to_dict())
