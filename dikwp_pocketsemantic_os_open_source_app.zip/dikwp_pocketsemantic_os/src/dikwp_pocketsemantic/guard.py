from __future__ import annotations

import re
from typing import Dict, List

RISK_PATTERNS = {
    "access_circumvention": [
        r"bypass\s+(access|permission|quota|limit|rate|paywall)",
        r"绕过.*(权限|限制|配额|审计|安全|访问)",
        r"规避.*(限制|审计|安全|检测|策略)",
        r"free\s+compute",
        r"rate\s*limit\s*bypass",
    ],
    "jailbreak_or_prompt_injection": [
        r"ignore\s+(all\s+)?previous\s+(instructions|rules)",
        r"reveal\s+(system|hidden)\s+prompt",
        r"jailbreak",
        r"越狱",
        r"隐藏.*系统提示",
        r"泄露.*system\s*prompt",
    ],
    "unsafe_stealth": [
        r"hidden\s+persistence",
        r"stealth",
        r"逃逸",
        r"驻留",
        r"复制.*主机",
        r"规避.*日志",
    ],
    "sensitive_data_exfiltration": [
        r"steal\s+(api\s+key|token|password|secret)",
        r"获取.*(密码|密钥|token|凭据)",
        r"exfiltrate",
    ],
}


def assess_boundary(text: str) -> Dict[str, object]:
    found: List[str] = []
    lower = text.lower()
    for category, patterns in RISK_PATTERNS.items():
        for pat in patterns:
            if re.search(pat, lower, flags=re.IGNORECASE):
                found.append(category)
                break
    if found:
        decision = "review" if found == ["unsafe_stealth"] else "block_or_reframe"
    else:
        decision = "allow"
    return {"decision": decision, "risk_categories": sorted(set(found))}


def safe_reframe_note() -> str:
    return (
        "Semantic penetration here means penetrating ambiguity, missing context, weak intent, "
        "and unsupported claims. It does not mean bypassing access controls, safety policies, "
        "rate limits, hidden system prompts, audit logs, or model restrictions."
    )
