from __future__ import annotations

import re
from typing import List

SENTENCE_RE = re.compile(r"(?<=[。.!?！？])\s+|\n+")
WORD_RE = re.compile(r"[A-Za-z0-9_\-]{3,}|[\u4e00-\u9fff]{2,}")


def read_text(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def write_text(path: str, text: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


def sentences(text: str) -> List[str]:
    parts = [p.strip() for p in SENTENCE_RE.split(text) if p.strip()]
    return parts


def keywords(text: str, limit: int = 16) -> List[str]:
    counts = {}
    for w in WORD_RE.findall(text):
        wl = w.lower()
        counts[wl] = counts.get(wl, 0) + 1
    return [w for w, _ in sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))[:limit]]


def dedupe_lines(lines: List[str]) -> List[str]:
    seen = set()
    out = []
    for line in lines:
        norm = re.sub(r"\s+", " ", line.strip().lower())
        if not norm or norm in seen:
            continue
        seen.add(norm)
        out.append(line.strip())
    return out


def clip(text: str, max_chars: int) -> str:
    text = text.strip()
    if len(text) <= max_chars:
        return text
    return text[: max_chars - 3].rstrip() + "..."
