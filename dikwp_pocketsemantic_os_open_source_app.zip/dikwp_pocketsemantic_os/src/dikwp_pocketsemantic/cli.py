from __future__ import annotations

import argparse
import json
import os
from .analyzer import load_profiles, make_capsule, micro_capsule, enhance_answer, model_attachment_prompt
from .static_audit import audit_tree
from .text_utils import read_text, write_text


def _ensure(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def cmd_build_capsule(args: argparse.Namespace) -> None:
    task = read_text(args.task)
    notes = read_text(args.notes) if args.notes else ""
    profile = load_profiles(args.profile)
    capsule = make_capsule(task, notes, profile, args.budget)
    _ensure(args.out)
    with open(os.path.join(args.out, "semantic_capsule.json"), "w", encoding="utf-8") as f:
        json.dump(capsule.to_dict(), f, ensure_ascii=False, indent=2)
    write_text(os.path.join(args.out, "semantic_capsule.txt"), capsule.compact_prompt)
    write_text(os.path.join(args.out, "micro_capsule.txt"), micro_capsule(capsule))
    write_text(os.path.join(args.out, "model_attachment_prompt.txt"), model_attachment_prompt(capsule))
    print(json.dumps({"decision": capsule.risk_decision, "out": args.out}, ensure_ascii=False, indent=2))


def cmd_enhance(args: argparse.Namespace) -> None:
    draft = read_text(args.answer)
    with open(args.capsule, "r", encoding="utf-8") as f:
        capsule = json.load(f)
    report = enhance_answer(draft, capsule)
    _ensure(args.out)
    with open(os.path.join(args.out, "answer_enhancement_report.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    write_text(os.path.join(args.out, "answer_repair_plan.md"), "# Answer Repair Plan\n\n" + "\n".join(f"- {x}" for x in report["repair_steps"]))
    print(json.dumps(report, ensure_ascii=False, indent=2))


def cmd_static_audit(args: argparse.Namespace) -> None:
    report = audit_tree(args.root)
    outdir = os.path.dirname(args.out)
    if outdir:
        os.makedirs(outdir, exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    print(json.dumps(report, ensure_ascii=False, indent=2))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="pocketsemantic")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("build-capsule")
    p.add_argument("task")
    p.add_argument("--notes")
    p.add_argument("--profile")
    p.add_argument("--budget", choices=["micro", "low", "normal", "audit"], default=None)
    p.add_argument("--out", default="outputs/demo")
    p.set_defaults(func=cmd_build_capsule)

    p = sub.add_parser("enhance")
    p.add_argument("answer")
    p.add_argument("--capsule", required=True)
    p.add_argument("--out", default="outputs/demo")
    p.set_defaults(func=cmd_enhance)

    p = sub.add_parser("static-audit")
    p.add_argument("root")
    p.add_argument("--out", required=True)
    p.set_defaults(func=cmd_static_audit)
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
