from __future__ import annotations

from typing import List
from .models import DIKWPRecord
from .text_utils import keywords, sentences, clip, dedupe_lines


def register_dikwp(task: str, notes: str = "") -> DIKWPRecord:
    combined = (task + "\n" + notes).strip()
    kws = keywords(combined, limit=20)
    sents = sentences(combined)
    data = dedupe_lines([clip(s, 160) for s in sents[:5]])
    information = [
        f"Key terms: {', '.join(kws[:10])}" if kws else "Key terms unavailable",
        "Context is constrained or portable; answers must be compact and transferable.",
        "Semantic capsule should separate task, evidence, purpose, constraints, residual, and requested output."
    ]
    knowledge = [
        "Use DIKWP: Data -> Information -> Knowledge -> Wisdom -> Purpose -> Reliability.",
        "Use evidence custody: claim, source, support scope, unsupported scope, residual, kill condition.",
        "Use answer repair: detect unsupported certainty, missing definitions, weak scope, and unclear action boundary."
    ]
    wisdom = [
        "Do not turn model limitations into jailbreak attempts.",
        "Prefer meaning-preserving compression over deceptive prompt manipulation.",
        "Preserve residuals instead of fabricating certainty under compute or access pressure."
    ]
    purpose = [
        "Increase answer quality under model, context, compute, or access constraints.",
        "Make the user's intent and boundaries explicit enough for weaker models to follow.",
        "Produce a portable attachment prompt that can be copied into another AI system lawfully."
    ]
    reliability = [
        "Local heuristic prototype; reliability is Supported/RunProof for formatting and guard behavior.",
        "External factual accuracy still depends on sources supplied by the user or available to the target model.",
        "Any target model output remains Borrowed Reliability and should be audited."
    ]
    return DIKWPRecord(data, information, knowledge, wisdom, purpose, reliability)
