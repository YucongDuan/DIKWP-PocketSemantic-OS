from __future__ import annotations

from dataclasses import dataclass, asdict, field
from typing import Dict, List, Any


@dataclass
class DIKWPRecord:
    data: List[str] = field(default_factory=list)
    information: List[str] = field(default_factory=list)
    knowledge: List[str] = field(default_factory=list)
    wisdom: List[str] = field(default_factory=list)
    purpose: List[str] = field(default_factory=list)
    reliability: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class SemanticCapsule:
    task: str
    budget_mode: str
    risk_decision: str
    risk_categories: List[str]
    dikwp: DIKWPRecord
    must_do: List[str]
    must_not_do: List[str]
    evidence_ledger: List[Dict[str, Any]]
    residual: List[str]
    answer_contract: Dict[str, Any]
    compact_prompt: str

    def to_dict(self) -> Dict[str, Any]:
        result = asdict(self)
        result["dikwp"] = self.dikwp.to_dict()
        return result
