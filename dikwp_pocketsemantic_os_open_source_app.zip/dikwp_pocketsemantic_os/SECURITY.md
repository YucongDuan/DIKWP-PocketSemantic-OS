# Security Policy

Report vulnerabilities privately. The project intentionally avoids network calls, subprocess execution, hidden persistence, hidden prompt extraction, and access-control bypass.
